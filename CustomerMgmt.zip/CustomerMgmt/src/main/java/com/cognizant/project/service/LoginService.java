package com.cognizant.project.service;

public interface LoginService {

	boolean validatingUser(String userName, String passWord);

}
