package com.cognizant.project.repository;

public interface LoginDAO {

	boolean validatingUser(String userName, String passWord);

}
