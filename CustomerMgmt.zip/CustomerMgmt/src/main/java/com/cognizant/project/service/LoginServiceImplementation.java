package com.cognizant.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.project.repository.LoginDAO;

@Service
public class LoginServiceImplementation implements LoginService{

	@Autowired
	LoginDAO loginDAO; 
	
	@Override
	@Transactional
	public boolean validatingUser(String userName, String passWord) {
		
		return loginDAO.validatingUser(userName,passWord);
		 
	}

	
}
