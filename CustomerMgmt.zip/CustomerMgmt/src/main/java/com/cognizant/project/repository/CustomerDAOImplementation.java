package com.cognizant.project.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.project.entity.Customer;

@Repository
public class CustomerDAOImplementation implements CustomerDAO {

	@Autowired
	private SessionFactory factory;

	@Override
	public List<Customer> getAllCustomers() {
		Session session=factory.getCurrentSession();
		
		//HQL Query
		Query<Customer> query=session.createQuery("from Customer order by firstName",Customer.class);
		List<Customer> customerlist=query.getResultList();
		System.out.println("List of customers are :");
		customerlist.forEach(c ->System.out.println(c));
		System.out.println("customer list ended");
		return customerlist;
		
	}

	@Override
	public void saveCustomer(Customer theCustomer) {
		Session session=factory.getCurrentSession();
		session.saveOrUpdate(theCustomer);
	}


	@Override
	public List<Customer> getCustomerByName(String customerName) {
	
//		int id=0,phn=0;
//		String firstName=null,lastName=null,gender=null,email=null;
//		Date dob=null;
//		
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useSSL=false","root","root");
//			PreparedStatement pst= con.prepareStatement("select * from Customer where first_name=?");
//			pst.setString(1, customerName);
//			ResultSet rs=pst.executeQuery();
//			
//			while(rs.next())
//			{
//				id=rs.getInt("id");
//				firstName=rs.getString("firstName");
//				lastName=rs.getString("lastName");
//				dob=rs.getDate("dob");
//				gender=rs.getString("gender");
//				email=rs.getString("email");
//				phn=rs.getInt("phn");
//			}
//			
//		}
//		catch(Exception e) {
//			System.out.println(e);
//		}
//		
//		Customer customer=new Customer(firstName, lastName, dob, gender, email, phn);
//		System.out.println("Just check :"+ id+firstName);
//
//		return customer;
		Session session=factory.getCurrentSession();
		String sql="from Customer where firstName='"+customerName+"'";
		Query<Customer> query=session.createQuery(sql,Customer.class);
		List<Customer> list=query.getResultList();
		return list;
	}
	
	@Override
	public Customer getCustomer(int customerId) {
		Session session=factory.getCurrentSession();
		Customer customer=session.get(Customer.class, customerId);
		return customer;
		
	}

	@Override
	public void deleteCustomer(int customerId) {
		Session session =factory.getCurrentSession();
		Customer customer=session.get(Customer.class, customerId);
		session.delete(customer);
	}


}

